Atari-Zakariyaye-Narazi-master   --->   Project Files 

TestCases  --->  Project TestCase

Atari_Zakariyaye_Razi_CppFile   --->   Alone Cpp File For Using TestCase

Challenge   ---> Report File

docx  Report --->Report Files in docx Format

Team Members :

	Iliya Mirzaie

	Amir Deldar

	Amir Mahdi Shadman 